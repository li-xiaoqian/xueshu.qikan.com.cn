﻿$(document).ready(function () {

    $(".cancel,.maga-tc-titR").click(function () {
        $(".maga-tc-con,.maga-tc-buy,.maga-tc-buy-noMoney,.maga-tc-buy-vip").fadeOut("fast");
        setTimeout(fade, 100);
    });
    function fade() {
        $("#fade").fadeOut();
    }
});

$(document).ready(function () {

    $(".AH-login-close,.login-tc-titR,.cancel,.maga-tc-titR,#fade").click(function () {
        $(".AH-login-wrap,.login-tc-wrap,.maga-tc-con").fadeOut("fast");
        setTimeout(fade, 100);
    });
    function fade() {
        $("#fade").fadeOut();
    }
});
$(document).unbind("keydown.spgl_sp_esc").bind("keydown.spgl_sp_esc", function (e) {
    var keyCode = window.event ? e.keyCode : e.which;
    if (keyCode == 27) {  //esc按钮
        $("#fade,.wy-tc,.czk-tc,.AH-login-wrap,.maga-tc-con,.maga-tc-buy,maga-tc-buy,.login-tc-wrap,.maga-tc-buy-noMoney,.maga-tc-buy-vip").fadeOut();

    }
});
function LoadFavoriteData(titleid) {
    var type = "CheckArticleFavorite";
    var datas = {titleid: titleid, type: type };
    $.ajax({
        type: "POST",
        url: "/Handle/MagazineProcess.ashx",
        data: datas,
        dataType: 'json',

        success: function (jsonResult) {
            if (jsonResult == null) {
                //  regon.find(".SortsConInfo").text('');
            }
            else {
                if (jsonResult == true) {
                    $(".m-sc").addClass("m-scc");
                    $(".m-sc").unbind().click(function () {
                        DelFavoriteData(titleid);
                    });
                    $(".m-sc").html("已收藏");
                }

            }
        }

    });
}
function AddFavoriteData(titleid) {
 
    var type = "AddArticleFavorite";
    var datas = { titleid: titleid,articletype:1, type: type };
  
    $.ajax({
        type: "POST",
        url: "/Handle/MagazineProcess.ashx",
        data: datas,
        dataType: 'json',
        success: function (jsonResult) {
            if (jsonResult == null) {
                //  regon.find(".SortsConInfo").text('');
            }
            else {
                if (jsonResult == 1) {
                    $(".tip-msg").fadeIn("fast").html("收藏成功");
                    setTimeout(function () { $(".tip-msg").fadeOut("fast") }, 1000);

                    $(".m-sc").addClass("m-scc");
                    $(".m-sc").unbind().click(function () {
                        DelFavoriteData(titleid);
                    });
                    $(".m-sc").html("已收藏");
                }
            }
        }

    });
}

function DelFavoriteData( titleid) {
   
    var type = "DelArticleFavorite";
    var datas = { titleid: titleid, type: type };
    $.ajax({
        type: "POST",
        url: "/Handle/MagazineProcess.ashx",
        data: datas,
        dataType: 'json',
        success: function (jsonResult) {
            if (jsonResult == null) {
                //  regon.find(".SortsConInfo").text('');
            }
            else {
                if (jsonResult == 1) {
                    $(".tip-msg").fadeIn("fast").html("已取消收藏");
                    setTimeout(function () { $(".tip-msg").fadeOut("fast") }, 1000);
                    $(".m-sc").removeClass("m-scc");
                    $(".m-sc").unbind().click(function () {
                        AddFavoriteData(titleid);
                    });
                    $(".m-sc").html("收藏");
                }
            }
        }

    });
}

function LoadMoreContent(titleid) {
    var type = "getmorecontent";
    var datas = { titleid: titleid, type: type };
    $.ajax({
        type: "POST",
        url: "/Handle/ArticleProcess.ashx",
        data: datas,
        dataType: 'json',

        success: function (jsonResult) {
            if (jsonResult == null) {
                //  regon.find(".SortsConInfo").text('');
            }
            else {
                    $(".textWrap").append(jsonResult);
            }
        }

    });
}
